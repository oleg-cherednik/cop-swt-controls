/*
 *  File: DefaultHierarchicalTableModel.java 
 *  Copyright (c) 2004-2007  Peter Kliem (Peter.Kliem@jaret.de)
 *  A commercial license is available, see http://www.jaret.de.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package de.jaret.util.ui.table.model;

/**
 * Default implementation of a hierarchical jaret table model.
 * 
 * @author Peter Kliem
 * @version $Id: DefaultHierarchicalTableModel.java 175 2007-01-05 00:01:18Z olk $
 */
public class DefaultHierarchicalTableModel implements IHierarchicalJaretTableModel {
    /** the root node. */
    protected ITableNode _root;

    /**
     * Construct the model.
     * 
     * @param root the root node
     */
    public DefaultHierarchicalTableModel(ITableNode root) {
        _root = root;
    }

    /**
     * {@inheritDoc}
     */
    public ITableNode getRootNode() {
        return _root;
    }

}
